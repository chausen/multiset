#include "COP3503su14_Proj2_Hausen.h"

int abs_count(int count)
{
	if (count < 0)
	{
		return -count;
	}
	else
		return count;
}

/*==================================================================================================*/
/*========================================== BEG MULTISET ==========================================*/
/*==================================================================================================*/

// Constructor
Multiset::Multiset() : output_type(NORMAL) {}

int Multiset::input_file(string filename)
{
	int load_outcome = load_into_temp(filename);

	if (load_outcome == SUCCESS)
	{
			current_set.clear();
			current_set = temp_set;
			temp_set.clear();
			return SUCCESS;
	}
	else
		return load_outcome;
}

int Multiset::union_file(string filename)
{
	int load_outcome = load_into_temp(filename);
	if (load_outcome == SUCCESS)
	{

		bool exists = false;

		// overflow_count is kept to undo changes if overflow occurs
		int overflow_count = 0;

		for (int t = 0; t < temp_set.size(); t++)
		{
			for (int c = 0; c < current_set.size(); c++)
			{
				if (temp_set[t] == current_set[c]) // if item already exists
				{
					current_set[c] + temp_set[t]; // add current and temp counts
					exists = true;
					continue;
				}
			}
			if (!exists)
			{
				current_set.push_back(temp_set[t]); // otherwise add item to current set
				++overflow_count;
			}
			else
				exists = false;
		}
		// Undo changes if overflow occurs
		if (current_set.size() > MAX_SIZE)
		{
			current_set.erase(current_set.begin() + overflow_count, current_set.end());
			cout << "ERROR: This union would make the current multiset larger than " << MAX_SIZE << " unique items." << endl
					<< "Union not completed." << endl;
			temp_set.clear();
			return OVERFLOW;
		}
		else
		{
			temp_set.clear();
			return SUCCESS;
		}
	}
	else
		return load_outcome;
}

int Multiset::subtract_file(string filename)
{
	int load_outcome = load_into_temp(filename);
	if (load_outcome == SUCCESS)
	{
		for (int t = 0; t < temp_set.size(); t++)
		{
			for (int c = 0; c < current_set.size(); c++)
			{
				if (temp_set[t] == current_set[c]) // if item exists
				{
					if (temp_set[t] >= current_set[c]) // and temp count is greater than current
					{
						current_set.erase(current_set.begin() + c); // delete item
						--c;
					}
					else
						current_set[c] - temp_set[t]; // otherwise subtract the count
				}
			}
		}
		temp_set.clear();
		return SUCCESS;
	}
	else
		return load_outcome;
}

int Multiset::difference_file(string filename)
{
	int load_outcome = load_into_temp(filename);
	if (load_outcome == SUCCESS)
	{
		int exists = false;

		for (int t = 0; t < temp_set.size(); t++)
		{
			for (int c = 0; c < current_set.size(); c++)
			{
				if (temp_set[t] == current_set[c])
				{
					if (current_set[c].get_count() == temp_set[t].get_count()) // if the COUNTS of current and temp set are the same
					{
						current_set.erase(current_set.begin() + c); // erase current item
						--c; 										// move index back to compensate for the deletion
					}
					else
						current_set[c].set_count(abs_count(current_set[c].get_count() - temp_set[t].get_count())); // otherwise, subtract the smaller of the two from the larger
					exists = true;
				}
			}
			if (!exists)
				current_set.push_back(temp_set[t]);
			else
				exists = false;
		}
		temp_set.clear();
		return SUCCESS;
	}
	else
		return load_outcome;
}

int Multiset::intersect_file(string filename)
{
	int load_outcome = load_into_temp(filename);
	if (load_outcome == SUCCESS)
	{
		vector<Item> temp;

		for (int t = 0; t < temp_set.size(); t++)
		{
			for (int c = 0; c < current_set.size(); c++)
			{
				// If the member string, 'item' is the same
				if (temp_set[t] == current_set[c])
				{
					// Use the smaller count of the two matching items
					if (current_set[c] <= temp_set[t])
						temp.push_back(current_set[t]);
					else
						temp.push_back(temp_set[c]);
				}
			}
		}
		current_set = temp;
		temp_set.clear();
		return SUCCESS;
	}
	else
		return load_outcome;
}

void Multiset::reset_set()
{
	current_set.clear();
}

int Multiset::output_file(string filename)
{
	ofstream output(filename.c_str());

	if (output.fail()){
		cerr << "ERROR: " << filename << " cannot be created" << endl;
		return FOPEN_FAIL;
	}

	int csize = current_set.size();
	for (int i = 0; i < csize; i++)
	{
		output << current_set[i].to_string();
		if (i != csize - 1) // Don't output a newline after the last item
			output << endl;
	}

	return SUCCESS;
}

void Multiset::print_set()
{
	for (int i = 0; i != current_set.size(); i++)
	{
		cout << current_set[i].to_string() << endl;
	}
}

bool Multiset::find_item(string item, int& count)
{
	bool found = false;
	for (int i = 0; i < current_set.size(); i++)
	{
		if (current_set[i].get_item() == item)
		{
			found = true;
			count = current_set[i].get_count();
			break;
		}
	}
	return found;
}

bool Multiset::insert_item(string item, int count)
{
	// Error checking for overflow
	int num_items = current_set.size();
	if (num_items >= MAX_SIZE)
	{
		cerr << "ERROR: Multiset already has " << num_items << " unique items (Max is " << MAX_SIZE << ")" << endl;
		return false;
	}

	for (int i = 0; i < current_set.size(); i++)
	{
		if (current_set[i].get_item() == item)
		{
			current_set[i].set_count(current_set[i].get_count() + count);
			if (output_type != SILENT)
				cout << "Item " << item << " inserted with count " << current_set[i].get_count() << endl;
			return true;
		}
	}

	// this code won't execute if the item was already found
	Item new_item(item, count);
	current_set.push_back(new_item);
	if (output_type != SILENT)
		cout << "Item " << item << " inserted with count " << count << endl;
	return true;
}

bool Multiset::delete_item(string item)
{
	for (int i = 0; i < current_set.size(); i++)
	{
		if (current_set[i].get_item() == item)
		{
			current_set.erase(current_set.begin() + i);
			return true;
		}
	}
	return false;
}

bool Multiset::reduce_item(string item, int count)
{
	for (int i = 0; i < current_set.size(); i++)
	{
		if (current_set[i].get_item() == item)
		{
			if (current_set[i].get_count() > count) // reduce the count if the current count is greater than input one
			{
				current_set[i].set_count(current_set[i].get_count() - count);
				if (output_type != SILENT)
					cout << "Item " << item << " reduced by " << count << endl;
			}
			else
			{
				current_set.erase(current_set.begin() + i); // otherwise delete current item
				if (output_type != SILENT)
					cout << "Item " << item << " removed" << endl;
			}

			return true;
		}
	}
	return false;
}

void Multiset::verbose_output()
{
	output_type = VERBOSE;
}

void Multiset::normal_output()
{
	output_type = NORMAL;
}

void Multiset::silent_output()
{
	output_type = SILENT;
}


void Multiset::help()
{
	cout << "======================================================================" << endl;
	cout
	<< "The numbered commands are as follows:" << endl
	<< "0. exit" << endl
	<< "1. input file <filename>: open and read a list from a file to the current multiset" << endl
	<< "2. union file <filename>: open and union a multiset from a file with the current multiset" << endl
	<< "3. subtract file <filename>: open and subtract multiset from a file from the current multiset" << endl
	<< "4. difference file <filename>: open and find the difference between a multiset from a file and the current multiset" << endl
	<< "5. intersect file <filename>: open and find the intersection between a multiset from a file and the current multiset" << endl
	<< "6. reset current multiset to the empty multiset" << endl
	<< "7. output file <filename>: open and write the current multiset to a file" << endl
	<< "8. print current multiset to the console" << endl
	<< "9. find <item name>: test if <item name> is in the current multiset" << endl
	<< "10. insert <item name> <count>: add <item name> to the current multiset with number <count> if <item name>"
			" is not in the current multiset, or increase <item name>'s number by <count> if it is" << endl
	<< "11. delete <item name>: remove <item name> from the current multiset if it is in it" << endl
	<< "12. reduce <item name> <count>: reduce the number of <item name> by <count>" << endl
	<< "13. verbose output" << endl
	<< "14. normal output" << endl
	<< "15. silent output" << endl
	<< "16. help" << endl
	<< "17. max <filename>: open and find the maximum between a multiset from a file" << endl;
	cout << "======================================================================" << endl;

	// Ensures this always gets printed when help is called
	if (output_type == SILENT)
		cout << "> " << flush;
}

int Multiset::max_file(string filename)
{
	int load_outcome = load_into_temp(filename);
	if (load_outcome == SUCCESS)
	{
		int count = 0;
		// overflow_count is kept to undo changes if overflow occurs
		int overflow_count = 0;

		for (int t = 0; t < temp_set.size(); t++)
		{
			for (int c = 0; c < current_set.size(); c++)
			{
				// Checks for equivalence of the item member of the two Item objects
				if (temp_set[t] == current_set[c])
				{
					/* If the item being read from the file has a greater count, that one is used //
					// If not, the count is still incremented to prevent another item being added //
					// to the current set														  */
					if (temp_set[t] > current_set[c])
					{
						current_set[c] = temp_set[t];
						++count;
						continue;
					}
					else
					{
						++count;
						continue;
					}
				}
			}
			if (count == 0)
			{
				current_set.push_back(temp_set[t]);
				++overflow_count;
			}
			else
				count = 0;
		}
		// Undo changes if overflow occurs
		if (current_set.size() > MAX_SIZE)
		{
			current_set.erase(current_set.begin() + count, current_set.end());
			cout << "ERROR: This union would make the current multiset larger than " << MAX_SIZE << " unique items." << endl
					<< "Union not completed." << endl;
			temp_set.clear();
			return OVERFLOW;
		}
		else
		{
			temp_set.clear();
			return SUCCESS;
		}
	}
	else
		return load_outcome;
}

/*==================================================================================================*/
/*======================================== HELPER FUNCTIONS ========================================*/
/*==================================================================================================*/

int Multiset::load_into_temp(string filename)
{
	// Create a filestream with the name "filename"
	ifstream ifile(filename.c_str());
	if (ifile) // if the file opened successfully
	{
		string line;
		string item;
		int count;

		// Keeps track of the number of lines so we know which one is malformed if an error occurs
		static int counter = 0;
		while (!ifile.eof())
		{
			if (capacity_reached(filename))
				return OVERFLOW;

			getline(ifile, line);
			++counter;
			istringstream lineparse(line);
			lineparse >> item >> count;

			// Print error if count is greater than max size for int
			if (count > 2147483646)
			{
				error_message(FMAX_COUNT, counter);
				continue;
			}

			// Print error if anything causes string stream to fail
			if (lineparse.fail())
			{
				error_message(FINPUT_FORMAT, counter);
				continue;
			}

			// Each time an Item is added, it is checked against what has already been added to consolidate any duplicates
			bool exists = false;
			for (int i = 0; i < temp_set.size(); i++)
			{
				if (temp_set[i].get_item() == item)
				{
					exists = true;
					current_set[i].set_count(current_set[i].get_count() + count);
				}
			}

			// If the item doesn't already exist and has a count > 0, add it
			if (!exists)
			{
				if (count > 0)
				{
					Item new_item(item, count);
					temp_set.push_back(new_item);
				}
				else
					error_message(FINPUT_FORMAT, counter);
			}

			// Check for remaining input
			if (!lineparse.eof())
			{
				lineparse >> line;
				if (!lineparse.fail())
				{
					error_message(EOL_GARBAGE, counter, line);
				}
			}

			item = "";
		}
		counter = 0;
		ifile.close();
		return SUCCESS;
	}
	else
	{
		return FOPEN_FAIL;
	}
}

int Multiset::get_output_type()
{
	return output_type;
}

void Multiset::set_output_type(int option)
{
	output_type = option;
}

/*==================================================================================================*/
/*======================================== ERROR HANDLING ==========================================*/
/*==================================================================================================*/

/* Returns true if the input file has more than MAX_SIZE elements *
 * and clears the temp_set										  */
bool Multiset::capacity_reached(string filename)
{
	if (temp_set.size() > MAX_SIZE)
	{
		cerr << "ERROR: " << filename << " has more than " << MAX_SIZE << " elements" << endl
				<< "Operation Failed" << endl;
		temp_set.clear();
		return true;
	}
	else
		return false;
}

void Multiset::error_message(int code)
{
	if (code == OVERFLOW)
	{
		cerr << "ERROR: The operation could not be completed because a set reached"
				" the maximum number of unique items (" << MAX_SIZE << ")" << endl;
	}
	else if (code == UINPUT_FORMAT)
	{
		if (output_type != SILENT)
		{
			cout << "======================================================================" << endl;
					cout << "To be inserted, an item must be formatted correctly; you must"
							" enter an item followed by a count." << endl;
					cout << "The item and count can either be entered on the same line,"
							" with a space between them, or on consecutive lines." << endl;
					cout << "The count must be greater than 0. If no count is entered"
							" it will be treated as if the count was 1." << endl;
			cout << "======================================================================" << endl;
		}
		cerr << "WARNING: Improper user input; not in correct format" << endl;
	}
	else if (code == UMAX_COUNT)
	{
		if (output_type != SILENT)
		{
			if (output_type == VERBOSE)
				cout << "ERROR: Maximum count is 2147483646 for an item" << endl;
			cerr << "ERROR: Maximum count is 2147483646 for an item" << endl;
		}
	}
}

void Multiset::error_message(int code, string filename)
{
	if (code == FOPEN_FAIL)
		cerr << "ERROR: Failure opening file: '" << filename << "'" << endl;
}

void Multiset::error_message(int code, int line_number)
{
	if (code == FINPUT_FORMAT)
	{
		if (output_type == VERBOSE)
			cout << "WARNING: Improper file format; line " << line_number << " skipped!" << endl;
		cerr << "WARNING: Improper file format; line " << line_number << " skipped!" << endl;
	}
	else if (code == FMAX_COUNT)
	{
		if (output_type == VERBOSE)
			cout << "WARNING: Maximum count is 2147483646 for an item; line " << line_number << " skipped!" << endl;
		cerr << "WARNING: Maximum count is 2147483646 for an item; line " << line_number << " skipped!" << endl;
	}
}

void Multiset::error_message(int code, int line_number, string line)
{
	if (code == EOL_GARBAGE)
	{
		if (output_type == VERBOSE)
			cout << "WARNING: Malformed line (" << line_number << "): " << line << endl;
		cerr << "WARNING: Malformed line (" << line_number << "): " << line << endl;
	}
}

/*==================================================================================================*/
/*========================================== END MULTISET ==========================================*/
/*==================================================================================================*/




