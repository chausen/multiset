#ifndef COP3503SU14_PROJ2_HAUSEN_H_
#define COP3503SU14_PROJ2_HAUSEN_H_
#include <iostream>
#include <fstream>
#include <vector>
#include <typeinfo>
#include <sstream>

using namespace std;

// Maximum number of unique items in current_set and temp_set
#define MAX_SIZE 10000
#define NOT_SILENT (set.get_output_type() != SILENT)
// Output Modes
const int NORMAL = 0;
const int VERBOSE = 1;
const int SILENT = 2;
// Error Types
const int SUCCESS = 0;
const int FOPEN_FAIL = 1; // file could not be opened
const int OVERFLOW = 2; // MAX_SIZE exceeded
const int FINPUT_FORMAT = 3; // Malformed items input from file
const int UINPUT_FORMAT = 4; // Malformed items input from user
const int EOL_GARBAGE = 5; // Line that could be read but had extra input at the end
const int FMAX_COUNT = 6; // Item from file with count greater than 2147483647
const int UMAX_COUNT = 7; // User input item with count greater than 2147483647

class Item
{
private:
	string item;
	int count;

public:
	Item(string, int);
	string to_string();

	// 						Necessary accessor/mutator methods				//
	//----------------------------------------------------------------------//
	string get_item();
	int get_count();
	void set_item(string);
	void set_count(int);

	// 							Operator Overloads							//
	//----------------------------------------------------------------------//
	void operator+(Item&);
	void operator-(Item&);
	bool operator==(Item&);
	bool operator>(Item&);
	bool operator<(Item&);
	bool operator>=(Item&);
	bool operator<=(Item&);
};


class Multiset
{
public:
	vector<Item> current_set;
	vector<Item> temp_set;
	int output_type; // 0 - NORMAL; 1 - VERBOSE; 2 - SILENT

public:
	Multiset();
	int input_file(string);
	int union_file(string);
	int subtract_file(string);
	int difference_file(string);
	int intersect_file(string);
	void reset_set();
	int output_file(string);
	void print_set();
	bool find_item(string, int&);
	bool insert_item(string, int);
	bool delete_item(string);
	bool reduce_item(string, int);
	void verbose_output();
	void normal_output();
	void silent_output();
	void help();
	int max_file(string);

	// 							Main helper function						//
	//----------------------------------------------------------------------//
	int load_into_temp(string);

	// 						Necessary accessor/mutator methods				//
	//----------------------------------------------------------------------//
	int get_output_type();
	void set_output_type(int);

	// 								Error handling							//
	//----------------------------------------------------------------------//
	bool capacity_reached(string);
	void error_message(int);
	void error_message(int, string);
	void error_message(int, int);
	void error_message(int, int, string);
};

#endif /* COP3503SU14_PROJ2_HAUSEN_H_ */
