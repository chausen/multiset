#include "COP3503su14_Proj2_Hausen.h"

/*==================================================================================================*/
/*============================================ BEG ITEM ============================================*/
/*==================================================================================================*/

Item::Item(string item, int count)
{
	this->item = item;
	this->count = count;
}

string Item::to_string()
{
	ostringstream oss;
	oss << item << " " << count;
	return oss.str();
}

string Item::get_item()
{
	return item;
}

int Item::get_count()
{
	return count;
}

void Item::set_item(string item)
{
	this->item = item;
}

void Item::set_count(int count)
{
	this->count = count;
}

// Changes the Item object invoking the function
void Item::operator+(Item &addend)
{
	this->count += addend.count;
}

// Changes the Item object invoking the function
void Item::operator-(Item &subtrahend)
{
	this->count -= subtrahend.count;
}

// Only the string member 'item' is checked for equality
bool Item::operator==(Item &other_item)
{
	return (this->item == other_item.item) ? true : false;
}

bool Item::operator>(Item &other_item)
{
	return (this->count > other_item.count) ? true : false;
}

bool Item::operator<(Item &other_item)
{
	return (this->count < other_item.count) ? true : false;
}

bool Item::operator>=(Item &other_item)
{
	return (this->count >= other_item.count) ? true : false;
}

bool Item::operator<=(Item &other_item)
{
	return (this->count <= other_item.count) ? true : false;
}

/*==================================================================================================*/
/*============================================ END ITEM ============================================*/
/*==================================================================================================*/
