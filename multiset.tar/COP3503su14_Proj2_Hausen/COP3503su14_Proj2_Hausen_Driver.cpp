#include "COP3503su14_Proj2_Hausen.h"

const string VERBOSE_TEXT =
"0 - exit, 1 - input <file>, 2 - union <file>, 3 - subtract <file>,\n"
"4 - difference <file>, 5 - intersect <file>, 6 - reset current set,\n"
"7 - write <file>, 8 - print, 9 - find <item>, 10 - insert <item>, 11 - delete <item> \n"
"12 - reduce <item> <count>, 13 - verbose, 14 - normal, 15 - silent, 16 - help, 17 - max <file>";


int main()
{
	Multiset set = Multiset();
	string line;
	int selection;
	// Will be used for filename or item, depending on selection
	string file_or_item;
	// User input item count. Initialized to 1 because the default behavior for not entering count is to act as if it is 1
	int count = 1;
	// Used for outputting correct error code text
	int code;
	set.help();
	cout << endl;
	cout << "> " << flush;

	/*==================================================================================================*/
	/*=============================================== MENU =============================================*/
	/*==================================================================================================*/

	while (getline(cin, line))
	{
		istringstream lineparse(line);
		lineparse >> selection >> file_or_item >> count;

		if (selection <= 17 and selection >= 0)
		{
			if (selection == 0)
			{
				cout << "Exiting program..." << endl;
				break;
			}
			else if (selection == 1)
			{
				string filename = file_or_item;
				code = set.input_file(filename);
				if ((code == SUCCESS) and (NOT_SILENT))
					cout << "New set loaded from " << filename << endl;
				else if (code == OVERFLOW)
					set.error_message(code);
				else if (code == FOPEN_FAIL)
					set.error_message(code, filename);
			}
			else if (selection == 2)
			{
				string filename = file_or_item;
				code = set.union_file(filename);
				if ((code == SUCCESS) and (NOT_SILENT))
					cout << filename << " union completed" << endl;
				else if (code == OVERFLOW)
					set.error_message(code);
				else if (code == FOPEN_FAIL)
					set.error_message(code, filename);
			}
			else if (selection == 3)
			{
				string filename = file_or_item;
				code = set.subtract_file(filename);
				if ((code == SUCCESS) and (NOT_SILENT))
					cout << filename << " subtraction completed" << endl;
				else if (code == OVERFLOW)
					set.error_message(code);
				else if (code == FOPEN_FAIL)
					set.error_message(code, filename);
			}
			else if (selection == 4)
			{
				string filename = file_or_item;
				code = set.difference_file(filename);
				if ((code == SUCCESS) and (NOT_SILENT))
					cout << filename << " difference completed" << endl;
				else if (code == OVERFLOW)
					set.error_message(code);
				else if (code == FOPEN_FAIL)
					set.error_message(code, filename);
			}
			else if (selection == 5)
			{
				string filename = file_or_item;
				code = set.intersect_file(filename);
				if ((code == SUCCESS) and (NOT_SILENT))
					cout << filename << " intersect completed" << endl;
				else if (code == OVERFLOW)
					set.error_message(code);
				else if (code == FOPEN_FAIL)
					set.error_message(code, filename);
			}
			else if (selection == 6)
			{
				set.reset_set();
				if (NOT_SILENT)
					cout << "Reset completed" << endl;
			}
			else if (selection == 7)
			{
				string filename = file_or_item;
				code = set.output_file(filename);
				if ((code == SUCCESS) and (NOT_SILENT))
					cout << "Save to " << filename << " completed" << endl;
				else if (code == OVERFLOW)
					set.error_message(code);
				else if (code == FOPEN_FAIL)
					set.error_message(code, filename);
			}
			else if (selection == 8)
			{
				cout << "Current multiset: " << endl;
				set.print_set();
			}
			else if (selection == 9)
			{
				string item = file_or_item;
				if (set.find_item(item, count))
				{
					if (NOT_SILENT)
						cout << "Item " << item << " found with count " << count << endl;
				}
				else
				{
					if (NOT_SILENT)
						cout << "Item " << item << " not found" << endl;
				}
			}
			else if (selection == 10)
			{
				string item = file_or_item;

				if (cin.fail() or (file_or_item.find_first_not_of(' ') == string::npos) or count <= 0)
				{
					set.error_message(UINPUT_FORMAT);
				}
				// Print error if count is greater than max size for int
				else if (count > 2147483646)
				{
					set.error_message(UMAX_COUNT);
				}
				else if (set.insert_item(item, count)) // else if used in case of overflow error
				{
					// Do nothing; handled in insert_item
					// This is done to ensure the final count is output if the item already existed
				}
			}
			else if (selection == 11)
			{
				string item = file_or_item;
				if (cin.fail())
				{
					set.error_message(UINPUT_FORMAT);
				}
				else if (set.delete_item(item))
				{
					if (NOT_SILENT)
						cout << "Item " << item << " deleted" << endl;
				}
				else
				{
					if (NOT_SILENT)
						cout << "Item " << item << " not in multiset" << endl;
				}
			}
			else if (selection == 12)
			{
				string item = file_or_item;
				if (cin.fail())
				{
					set.error_message(UINPUT_FORMAT);
				}
				else if (set.reduce_item(item, count))
				{
					// do nothing; everything contained in function
				}
				else
				{
					if (NOT_SILENT)
						cout << "Item " << item << " not in multiset" << endl;
				}
			}
			else if (selection == 13)
			{
				set.verbose_output();
			}
			else if (selection == 14)
			{
				set.normal_output();
			}
			else if (selection == 15)
			{
				set.silent_output();
			}
			else if (selection == 16)
			{
				set.help();
			}
			else if (selection == 17)
			{
				string filename = file_or_item;
				code = set.max_file(filename);
				if ((code == SUCCESS) and (NOT_SILENT))
					cout << "Max completed" << endl;
				else if (code == OVERFLOW)
					set.error_message(code);
				else if (code == FOPEN_FAIL)
					set.error_message(code, filename);
			}
		}
		else
		{
			cerr << "ERROR: Invalid command. Enter '16' for a list of commands" << endl;
			if (NOT_SILENT)
				cout << VERBOSE_TEXT << endl;
		}

		PROMPT:
		if (set.get_output_type() == NORMAL)
		{
			cout << "> " << flush;
		}
		else if (set.get_output_type() == VERBOSE)
		{
			cout << VERBOSE_TEXT << endl;
			cout << "> " << flush;
		}
		else if (set.get_output_type() == SILENT)
		{
			cout << flush;
		}
		else
		{
			set.set_output_type(NORMAL);
			cout << "> " << flush;
		}

		file_or_item = "";
		count = 1;
	}

	return 0;
}

	/*==================================================================================================*/
	/*============================================= END MENU ===========================================*/
	/*==================================================================================================*/







